import './App.css';
import { Route, Routes } from 'react-router-dom';
import Market from './components/Market';
import Search from './components/Search';
import { useState } from 'react';

function App() {
  const [SearchDateString ,setSearchDateString] = useState();
  const [SelectedEndDateString ,setSelectedEndDateString] = useState();
  const [isRangeSearch , setIsRangeSearch] = useState();
  return (
    <>
      <Routes>
        <Route path='/' element={<Market/>} />
        <Route path='/search' element={<Search />} />
      </Routes>
    </>


  );
}

export default App;
