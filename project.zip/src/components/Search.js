import React, { useState } from 'react'
import DatePicker from 'react-datepicker';
import { styled } from 'styled-components'
import 'react-datepicker/dist/react-datepicker.css'
import {ko} from 'date-fns/esm/locale'
import {addDays, subDays} from 'date-fns'

function Search() {
  const [dateRange, setDateRange] = useState([null, null]);
  const [startDate, endDate] = dateRange;

        const StyleDate = styled(DatePicker)`
          border: 1px solid #ddd;
          background-color: lightcoral;
          width: 300px;
        `

  return (
    <>
       <StyleDate 
            locale={ko}
            selectsRange={true}
            startDate={startDate}
            endDate={endDate}
            onChange={(date)=>setDateRange(date)}
            dateFormat="yyyy년 MM월 dd"

            minDate={subDays(new Date(), 0)}
            maxDate={addDays(new Date(), 300)}
            monthsShown={5}
        />
    </>
  )
  };


export default Search